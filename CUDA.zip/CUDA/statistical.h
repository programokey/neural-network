#ifndef STATISTIACL_H
#define STATISTIACL_H
matrix get_feature(std::vector<real> &statistical_data, matrix &feature);
void generate_statistical_data(int type, int count, std::vector<real> &data);
#endif // !STATISTIACL_H
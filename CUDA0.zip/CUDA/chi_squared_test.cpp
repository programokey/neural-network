#include "chi_squared_test.h"
// fitting.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <iostream>
#include <cmath>
#include <vector>
#include <random>
#include <ctime>
#include <cstdio>
#define Pi 3.1415926

typedef long double real;
void generate_statistical_data1(int type, int count, std::vector<real> &data)
{
	std::default_random_engine engine(time(NULL));
	data.resize(count);
	switch (type)
	{
	case 1:
	{
		std::uniform_real_distribution<real> parameter1(-20, 20);
		std::uniform_real_distribution<real> parameter2(1e-3, 10000);
		std::normal_distribution<real> normal(5, 10);
		for (int i = 0; i < count; i++)
			data[i] = normal(engine);
		break;
	}
	}
}

real f(real x) {
	return exp(-(x*x) / 2);
}

real integrate(real(*f)(real), real a, real b)
{
	real dt = 1e-8;
	int n = (b - a) / dt;
	real res = f(a) + f(b);
	//#pragma omp parallel for num_threads(threads_count)
	for (int i = 1; i < n; i++)
		res += 2 * f(a + i*dt) + 4 * f(a + i*dt + dt / 2);
	return res*dt / 6;
}

real chisquare(int n) {
	switch (n) {
	case 1:return 3.843;
	case 2:return 5.992;
	case 3:return 7.815;
	case 4:return 9.488;
	case 5:return 11.070;
	case 6:return 12.592;
	case 7:return 14.067;
	case 8:return 15.507;
	case 9:return 16.919;
	case 10:return 18.307;
	case 11:return 19.675;
	case 12:return 21.026;
	case 13:return 22.362;
	case 14:return 23.685;
	case 15:return 24.996;
	case 16:return 26.296;
	case 17:return 27.587;
	case 18:return 28.869;
	case 19:return 30.143;
	case 20:return 31.410;
	case 21:return 32.670;
	case 22:return 33.924;
	case 23:return 35.172;
	case 24:return 36.415;
	case 25:return 37.652;
	case 26:return 38.885;
	case 27:return 40.113;
	case 28:return 41.337;
	case 29:return 42.557;
	case 30:return 43.773;
	case 31:return 44.985;
	case 32:return 46.194;
	case 33:return 47.400;
	case 34:return 48.602;
	case 35:return 49.802;
	case 36:return 50.998;
	case 37:return 52.192;
	case 38:return 53.384;
	case 39:return 54, 572;
	case 40:return 55, 758;
	default:return 0.5*pow((1.645 + sqrt(2 * n - 1)), 2);
	}

}

bool normal_distribution_fitting(int parameter1, int paramater2, std::vector<real> &data) {
	int a[15] = { 0 }, p[15] = { 0 }, j = 0, result1 = 0, result2 = 0, i;
	for (i = 0; i < 100; i++)                     //1
		if (data[i] <= -25) a[j]++;
	p[j] += 1 / sqrt(2 * Pi)*integrate(f, -1000, -25);
	if (p[j] >= 5)j++;
	for (i = 0; i < 100; i++)                    //2
		if (data[i] <= -15 && data[i]>-25) a[j]++;
	p[j] += 1 / sqrt(2 * Pi)*integrate(f, -25, -15);
	if (p[j] >= 5)j++;
	for (i = 0; i < 100; i++)                      //3
		if (data[i] <= -5 && data[i]>-15) a[j]++;
	p[j] += 1 / sqrt(2 * Pi)*integrate(f, -15, -5);
	if (p[j] >= 5)j++;
	for (i = 0; i < 100; i++)                     //4
		if (data[i] <= 0 && data[i]> -5) a[j]++;
	p[j] += 1 / sqrt(2 * Pi)*integrate(f, -5, 0);
	if (p[j] >= 5)j++;
	for (i = 0; i < 100; i++)                      //5
		if (data[i] <= 5 && data[i]>0) a[j]++;
	p[j] += 1 / sqrt(2 * Pi)*integrate(f, 0, 5);
	if (p[j] >= 5)j++;
	for (i = 0; i < 100; i++)                          //6
		if (data[i] <= 15 && data[i]>5) a[j]++;
	p[j] += 1 / sqrt(2 * Pi)*integrate(f, 5, 15);
	if (p[j] >= 5)j++;
	for (i = 0; i < 100; i++)                       //7
		if (data[i] <= 25 && data[i]>15) a[j]++;
	p[j] += 1 / sqrt(2 * Pi)*integrate(f, 15, 25);
	if (p[j] >= 5)j++;
	for (i = 0; i < 100; i++)                       //8
		if (data[i]>25) a[j]++;
	p[j] += 1 / sqrt(2 * Pi)*integrate(f, 25, 1000);
	while (p[j] < 5) {
		p[j] += p[j - 1];
		j--;
	}
	for (i = 0; i <= j; i++)
		result1 = a[j] * a[j] / (100 * p[j]);
	result1 -= 100;

	result2 = chisquare(j - 2 - 1);

	if (result1 > result2)
		return false;
	else
		return true;
}
int chi_squared_test()
{
	std::vector <real> data;
	generate_statistical_data1(1, 100, data);
	if (normal_distribution_fitting(10, 1, data) == 1)
		std::cout << "right" << std::endl;
	else
		std::cout << "false" << std::endl;
	return 0;
}

#pragma once
int chi_squared_test();

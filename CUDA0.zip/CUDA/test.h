#pragma once
#include "matrix.cuh"
void test_saved();
real test(int training_set_size, int batch_size, real lambda, real learning_rate);
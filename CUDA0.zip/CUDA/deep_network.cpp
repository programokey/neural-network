// deep_network.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <stdio.h>
#include <stdlib.h>
#include <random>
#include <vector>
#include <omp.h>
#include <ctime>
#include <cmath>
#include "matrix.h"
#include "network.h"
#include "test.h"
#include "calculus.h"
#include "distribution_classification.h"
void test_lognormal()
{
	int count = 10000;
	std::default_random_engine engine(time(NULL));
	std::uniform_real_distribution<real> parameter1(-2, 10);
	std::uniform_real_distribution<real> parameter2(1e-3, 3);
	std::lognormal_distribution<> lognormal(10, 3);
	FILE* f = fopen("lognormal.txt","w");
	for (int i = 0; i < count; i++)
		fprintf(f,"%g\n", lognormal(engine));
	fclose(f);
}
#include <random>
matrix get_class(matrix& out)
{
	matrix index = ones(1, size(out, 2));
#pragma omp parallel num_threads(threads_count)
	for (int j = 1; j <= size(out, 2); j++)
#pragma omp for 
		for (int i = 2; i <= size(out, 1); i++)
			if (out(i, j) > out(index(j), j))
				index(j) = i;
	return index;
}
#include "chi_squared_test.h"
int main()
{
	chi_squared_test();
	//test_distribution(100);
	/*std::default_random_engine engine;
	std::poisson_distribution<> poisson(3);
	std::normal_distribution<> normal(2,0.1);
	FILE* f = fopen("normal.txt", "w");
	for (int i = 0; i < 1000; i++)
		fprintf(f, "%f\n", normal(engine));*/
	//test_lognormal();
	//distribution_classification(2560, 256, 1e-3, 1e-3);
	//test_distribution_classification(10000);
	//test(256*10, 256, 1e-3, 1e-3);
	//retrain_distribution_classification(1024, 256, 1e-3, 1e-3);
	//test_saved();
	//print_time();
	system("pause");
    return 0;
}
//modfiy the function used to estamite arguments of binomial distribution !!!!
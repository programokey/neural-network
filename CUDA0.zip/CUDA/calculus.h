#ifndef  CALCULUS_H
#define CALCULUS_H
#include "matrix.cuh"
real derivative(real(*f)(real), real x);
real integrate(real(*f)(real), real a, real b, real dt);//Simpson Method
#endif // ! CALCULUS_H

#include <cmath>
#include "matrix.cuh"
#include "calculus.h"
const int threads_count = 12;
real derivative(real(*f)(real), real x)
{
	real dt = 1e-8;
	return (f(x + dt) - f(x - dt)) / (2 * dt);
}
real integrate(real(*f)(real), real a, real b,real dt)
{
	int n = (b - a) / dt;
	real res = f(a) + f(b);
//#pragma omp parallel for num_threads(threads_count)
	for (int i = 1; i < n; i++)
		res += 2 * f(a + i*dt) + 4 * f(a + i*dt + dt / 2);
	return res*dt / 6;
}